var helpers = (function () {
    function parseToMoney(value) {

    }
}());