/// <reference path="http-request.js" />
var helpers = (function () {
    function parseToMoney(value) {

    }
}());