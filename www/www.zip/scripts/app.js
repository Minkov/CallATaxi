/// <reference path="_refference.js" />

var app = app || {};

(function() {
    document.addEventListener("deviceready", function() {
        app.servicesUrl = "http://taxiornot.apphb.com/api/";
        //app.servicesUrl = "http://localhost:60415/api/";
        new kendo.mobile.Application();
        httpRequest.get(app.servicesUrl + "init")
            .then(function () {

            });
        loadUserInfo();
    }); 
    
    function loadUserInfo() {               
        var phoneId = device.uuid;
        window.phoneId = CryptoJS.SHA1(phoneId).toString();
    }
}());