﻿/// <reference path="libs/sha1.js" />
/// <reference path="libs/sha1.js" />
/// <reference path="libs/jquery.min.js" />
/// <reference path="libs/rsvp.min.js" />
/// <reference path="libs/kendo/kendo.mobile.min.js" />
/// <reference path="app/cities-view-model.js" />
/// <reference path="app/taxi-details-view-model.js" />
/// <reference path="app/users-view-model.js" />
